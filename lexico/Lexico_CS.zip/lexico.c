#include "lexico.h"
 
int main(int argc, char **argv){                                // Main - Somente um switch para as modularizacoes

    FILE *read;                                                 // Ponteiro que irá ler o arquivo.
    read = fopen (argv[1],"r");                                // Ponteiro "read" abre o arquivo de entrada e fará a leitura dos caracteres do arquivo
    if (!read){                                                 // Caso o ponteiro "read" não ler nada, aparecerá a mensagem de erro.
        printf (" ---> ARQUIVO NAO ENCONTRADO <--- \n");
        exit (1);
    }
    while(!feof(read)){
        fgets(buffer, TAM_BUFFER, read);
        buffersize = strlen(buffer);

        for( PosInLine = 0; PosInLine <= buffersize  ; PosInLine++){
            
            atual = buffer[PosInLine];
            sentinelA = buffer[PosInLine];
            sentinelB = buffer[PosInLine + 1];
            
            if( atual == '\n' || atual == '\0' || (sentinelA == '/' && sentinelB == '/') || (sentinelA == '*' && sentinelB == '/')){            
                LCount++;
                break;
            }else if( atual == ' ' || atual == '\t' ){
                continue;
            }

            Arraytokens[TKcount].Type = setype(atual);
            Arraytokens[TKcount].LineNumber = LCount;
            Arraytokens[TKcount].PosInLine = PosInLine;
            newToken(read, Arraytokens[TKcount].Type, TKcount, LCount, PosInLine);
        }
    }
}
